#include "App.h"

int main()
{
	App app;
	app.init();
	app.run();

	return 0;
}