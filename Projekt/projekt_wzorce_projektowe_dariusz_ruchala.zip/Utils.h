#ifndef UTILS_H
#define UTILS_H
#include <SFML/Config.hpp>
#include <Box2D/Box2D.h>
#define FACTOR 50

float32 pixels2Meters(float pixels);
float meters2pixels(float32 meters);

#endif